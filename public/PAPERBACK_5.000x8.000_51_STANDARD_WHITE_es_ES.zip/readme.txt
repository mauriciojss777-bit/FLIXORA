*Cómo utilizar su plantilla*

1. Abra el archivo de la plantilla en PDF o PNG de la portada del libro de tapa blanda en el programa de edición de imágenes que utilice.
2. Con este mismo programa, cree una nueva capa. Esta capa será la capa de diseño.
3. Cree su portada en la capa de diseño con la plantilla en PDF o PNG como guía. El diseño debe extenderse hasta el borde exterior de la zona rosa de la plantilla para evitar que aparezca un borde blanco cuando se imprima. La capa guía está alineada según nuestras especificaciones de impresión, así que no debe moverla.
4. Compruebe que el texto o las imágenes que se tienen que ver no están dentro de las zonas rosas de la plantilla.
5. La zona amarilla es para el código de barras. No debe colocar imágenes importantes ni texto que quiera que se lea en el lugar donde estará situado el código de barras. Le recomendamos aplicar en esta zona su color o diseño de fondo. KDP generará un código de barras automáticamente para el ISBN de su título cuando se impriman las copias.
6. Cuando el diseño esté terminado, deberá desactivar la capa guía para que no se imprima en el producto final y para pasar el proceso de revisión de la cubierta. Si no puede desactivar la capa guía, tendrá que darle formato al diseño para que la cubra completamente.
7. Aplane todas las capas, guarde el archivo como PDF con calidad de prensa con perfil de color CMYK y suba el archivo a KDP.
